Sponsor image uploads — MCSS 2026–2027

Upload these nine files into Cloudinary folder mcss/sponsors. Keep each filename stem as its public ID (for example, cuisine_formosa.jpg becomes mcss/sponsors/cuisine_formosa). Disable automatic unique filename suffixes or set the public ID explicitly. After upload, remove each localImage field from data/sponsors.ts so the site uses Cloudinary.

Image sources:
accio_cup.jpg — https://www.ccas.club/sponsors (Accio Cup image)
cuisine_formosa.jpg — https://www.clevercanadian.ca/best-taiwanese-restaurants-montreal/
majesthe.jpg — https://www.lemajesthe.com/en
marche_newon_downtown.jpg — https://march-newondowntown.wheree.com/
new_oriental.jpg — https://restoenligne.com/en/restaurants/home/new-oriental
nouilles_zhonghua.jpg — https://nouilles-zhonghua-chinese-noodles.localoria.com/
oh_dumplings_express_concordia.png — https://ohdumplings.ca/
onigiri_shop_concordia.png — https://www.ccas.club/sponsors (Onigiri Shop image)
salon_rium.jpg — https://www.fresha.com/fr/a/salon-rium-coiffure-monteuriol-570-avenue-du-president-kennedy-gp9vj3c0

Note: Some images are photos of the business or products, not official logos.
